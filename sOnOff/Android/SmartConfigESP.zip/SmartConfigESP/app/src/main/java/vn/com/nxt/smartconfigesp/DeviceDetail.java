package vn.com.nxt.smartconfigesp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.io.IOException;

public class DeviceDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_detail);
        final TextView tvStatus = findViewById(R.id.tvDetailStatus);
        final TextView tvDeviceTitle = findViewById(R.id.tvDetailTitle);
        final EditText edtRepeat = findViewById(R.id.edtDetailTime);
        final TextView tvDeviceID = findViewById(R.id.tvDetailDeviceID);

        Intent i = getIntent();
        final String deviceName = i.getStringExtra("device_name").trim();
        final String deviceID = i.getStringExtra("description").trim();

        tvDeviceTitle.setText("DEVICE: "+deviceName);
        tvDeviceID.setText("ID: "+deviceID);

        final Button btnSend = findViewById(R.id.btnDetailSet);
        btnSend.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final Firebase state = new Firebase("https://sonoff-6b6ea.firebaseio.com/device"+deviceID);
                state.child("repeat").setValue(Integer.parseInt(edtRepeat.getText().toString()));
                state.child("state").setValue(3);
                state.child("running").setValue(3);
            }
        });

        final Button btnTurnOn = findViewById(R.id.btnDetailTurnOn);
        btnTurnOn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final Firebase state = new Firebase("https://sonoff-6b6ea.firebaseio.com/device"+deviceID);
                state.child("state").setValue(1);
                state.child("running").setValue(1);
            }
        });

        final Button btnTurnOff = findViewById(R.id.btnDetailTurnOff);
        btnTurnOff.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final Firebase state = new Firebase("https://sonoff-6b6ea.firebaseio.com/device"+deviceID);
                state.child("state").setValue(0);
                state.child("running").setValue(2);
            }
        });



        //Toast.makeText(DeviceDetail.this, "Device " + device_number, Toast.LENGTH_SHORT).show();
        TextView tvConnectionStatus = findViewById(R.id.tvConnecttionState);
        tvConnectionStatus.setText("connected");
        tvConnectionStatus.setTextColor(Color.GREEN);
        //Setup Firebase

//        Firebase.setAndroidContext(this);
//        final Firebase root = new Firebase("https://sonoff-6b6ea.firebaseio.com/device"+deviceID+"/state");
//

        try {

            Toast.makeText(DeviceDetail.this, "connecting", Toast.LENGTH_SHORT).show();


            Firebase.setAndroidContext(this);
            final Firebase root = new Firebase("https://sonoff-6b6ea.firebaseio.com/device" + deviceID + "/state");


            root.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    if (dataSnapshot.getValue().toString().equals("1")) {
                        //Toast.makeText(DeviceDetail.this, "Device: ON " , Toast.LENGTH_SHORT).show();
                        tvStatus.setText("STATUS: ON");
                        tvStatus.setTextColor(Color.GREEN);

                    } else {
                        //Toast.makeText(DeviceDetail.this, "Device: OFF " , Toast.LENGTH_SHORT).show();
                        tvStatus.setText("STATUS: OFF");
                        tvStatus.setTextColor(Color.BLACK);
                    }

                    //state.setText("123");
                }

                @Override
                public void onCancelled(FirebaseError firebaseError) {

                }
            });
        }
        catch (Exception e)
        {
            Toast.makeText(DeviceDetail.this, "Can not connect " , Toast.LENGTH_SHORT).show();
        }
    }
}
