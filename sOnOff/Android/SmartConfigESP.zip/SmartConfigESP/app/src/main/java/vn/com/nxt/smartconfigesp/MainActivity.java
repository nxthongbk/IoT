package vn.com.nxt.smartconfigesp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.Firebase;

import java.util.ArrayList;

import vn.com.nxt.smartconfigesp.demo_activity.EsptouchDemoActivity;

import static android.provider.AlarmClock.EXTRA_MESSAGE;
import static vn.com.nxt.smartconfigesp.R.*;

public class MainActivity extends AppCompatActivity {

    Firebase root;
    boolean bState= false;
    ImageView imgState;
    private ListView lvContact;
    int[] color = {Color.RED, Color.GREEN,Color.GRAY, Color.YELLOW,Color.BLACK, Color.BLUE,Color.CYAN, Color.GREEN};

    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);

        lvContact = (ListView) findViewById(R.id.lv_Contact);
        final TextView tvDevices = findViewById(R.id.tv_Devices);
        final SharedPreferences pre=getSharedPreferences("device_list", MODE_PRIVATE);
        final ArrayList<Device> arrDevice = new ArrayList<>();;



        //-------Display List of Device -----------------
        //Get preferences
        String device_list = pre.getString("device_list", "");
        if(!device_list.equalsIgnoreCase(""))
        {



            String[] devices = device_list.split(";");
            for (int i=0;i<devices.length;i++)
            {
                Device device1 = new Device(devices[i].split(",")[0],devices[i].split(",")[1], color[i]);
                arrDevice.add(device1);
            }

            //Toast.makeText(MainActivity.this, arrDevice.get(0).getDescription()+"", Toast.LENGTH_SHORT).show();

            tvDevices.setText("Total: "+arrDevice.size()+"  " );

            CustomAdapter customAdaper = new CustomAdapter(this,R.layout.row_listview,arrDevice);
            lvContact.setAdapter(customAdaper);
            lvContact.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view,
                                        int position, long id) {



                    //Toast.makeText(MainActivity.this, "You Clicked at " + arrDevice.get(position).getDescription()+"", Toast.LENGTH_SHORT).show();
                    Intent detailDevice = new Intent(view.getContext(), DeviceDetail.class);
                    detailDevice.putExtra("device_name", arrDevice.get(position).getName()+"");
                    detailDevice.putExtra("description", arrDevice.get(position).getDescription()+"");
                    view.getContext().startActivity(detailDevice);
                }
            });
        }



        // Adding Device ---------------------------
        final Button button = findViewById(id.btnAdd);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
//                String current_device_list = pre.getString("device_list", "");
//                SharedPreferences.Editor editor = pre.edit();
//                editor.putString("device_list", current_device_list+"Device 1:bed room 1;");
//                editor.apply();

                Intent createNewDevice = new Intent(v.getContext(), CreateNewDevice.class);
                v.getContext().startActivity(createNewDevice);
            }
        });
    }
}
